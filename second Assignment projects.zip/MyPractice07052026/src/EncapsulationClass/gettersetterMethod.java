package EncapsulationClass;
class g1
{
	private String name;
	private int id;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}



public class gettersetterMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
