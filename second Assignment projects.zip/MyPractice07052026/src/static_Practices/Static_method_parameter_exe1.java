package static_Practices;

class d
{
	static int sum (int x, int y)
	{
		return x + y;
	}
}

public class Static_method_parameter_exe1 {

	public static void main(String[] args) {
	
	System.out.println(	d.sum(10, 20));

	}

}
