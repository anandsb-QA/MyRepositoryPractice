package static_Practices;
class x1
{
	static int id;
	static String name;
	
	x1(int i,String n)
	{
		id=i;
		name=n;
	}
	
	static void display()
	{
		System.out.println(id +" "+name);
		
	}
	
}

public class StaticforConstructor {

	public static void main(String[] args) {
	
		new x1(11 ,"Anu");
 x1.display();
 new x1(12 ,"Aju");
 x1.display();
 
	}

}
