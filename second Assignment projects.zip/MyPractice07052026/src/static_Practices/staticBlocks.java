package static_Practices;

public class staticBlocks {

	static
	{
		System.out.println("hey its me Anand");  // if there is a static block 
		                                          //it will execute first before main method
		                                           //and it will execute only one time	
	}
	public static void main(String[] args) {
		
	System.out.println("hey java");
	}

}
