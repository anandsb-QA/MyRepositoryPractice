package static_Practices;
class c2
{
	static String colour="Red";
}

class c3 extends c2
{
	static  String colour ="Black";
	
	 void test()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
}

public class superWithStatic_exe1 {

	public static void main(String[] args) {
		
		c3 obj=new c3();
		obj.test();			
	}

}
