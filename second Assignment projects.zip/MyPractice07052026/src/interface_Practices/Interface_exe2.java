package interface_Practices;
interface company
{
	static void company_name()
	{
      System.out.println("Zonal technologies");
	}
	void employee_name();
	void Salary();
	int x =25000;
}

class employee1 implements company
{
	
	public void employee_name()
	{
		System.out.println("Anand SB");
	}
	public void Salary()
	{
		System.out.println(x+5000);
	}	
}

class employee2 implements company
{
	public void employee_name()
	{
		System.out.println("Swathy CS");
	}
	public void Salary()
	{
		System.out.println(x+15000);
	}	
}


public class Interface_exe2 {

	public static void main(String[] args) {
	    company.company_name();
		company  ref=new employee1();
		ref.employee_name();
		ref.Salary();
		company ref1 =new employee2();
		ref1.employee_name();
		ref1.Salary();
	}

}
