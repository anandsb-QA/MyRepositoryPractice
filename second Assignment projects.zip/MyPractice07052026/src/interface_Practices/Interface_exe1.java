package interface_Practices;

interface a
{
	void run();  // by default abstract method
	void test();  // by default abstract method
	int x =25;   //by default its a static and final varibale

}
 class m1 implements a
 {
	 public void run()
	 {
		 System.out.println("hello");
	 }
	 public void test()
	 {
		 System.out.println("World");
	 }
	 public void m1method()           //  m1 class own method 
	 {
		 System.out.println("M1 own method ");
	 }
 }

class m2 extends m1
{
	void m2method()
	{
		System.out.println("m2 own method");
	}
}

public class Interface_exe1 {

	public static void main(String[] args) {
	      a ref=new m1();
			ref.run();
		    ref.test();
		m2 obj=new m2();
		obj.m1method();
		obj.m2method();
				
	}

}
