package Arraypractice;

import java.util.Arrays;

public class Methods_inArray_equal_exe1 {

	public static void main(String[] args) {
		
		int[]a= {1,2,3,4,5};
		int[]b= {1,2,3,4,5};
		
	boolean	flag = Arrays.equals(a, b);
	{
      System.out.println(flag);
	}

}
}