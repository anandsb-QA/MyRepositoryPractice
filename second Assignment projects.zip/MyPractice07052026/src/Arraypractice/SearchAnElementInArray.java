package Arraypractice;

import java.util.Scanner;

public class SearchAnElementInArray {

	public static void main(String[] args) {
		
		int[]a= {10,20,30,40,50};
		System.out.println("ENter the element");

		Scanner sc=new Scanner(System.in);
		int x=sc.nextInt();
		
		boolean found = false;
				
		for(int i=0; i<a.length; i++)
		{
			if(a[i]==x)
			{
				System.out.println("Eement Found "+ a[i]);
				found=true;
				break;
			}
			if(!found )
			{
				System.out.println("Element not found");
			
			}
		}
		sc.close();
	}

}
