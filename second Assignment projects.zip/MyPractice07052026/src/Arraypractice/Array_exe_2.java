package Arraypractice;

public class Array_exe_2 {

	public static void main(String[] args) {
     
		int [] a= {25,23,26,28,100};
		
		for (int i =0;  i< a.length; i++)
		{
			System.out.println(a[i]);
		}
		
		
		
		
	}

}
