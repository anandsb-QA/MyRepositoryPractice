package Arraypractice;

public class Array_exe_1 {

	public static void main(String[] args) {
		
		int [] a=new int[5];
		
		a[0]=10;
		a[1]=100;
		a[2]=1000;
		a[3]=10000;
		a[4]=100000;
		
		for (int i=0; i< a.length; i++)
		{
			System.out.println(a[i]);
		}
		
	}

}
