package Arraypractice;

import java.util.Arrays;

public class Method_equals_exe2 {

	public static void main(String[] args) {
		
		int[]a= {1,100,1000,200,2345};
		int[]b= {12,234,345,9876,4567,765}; // because both arrays index length is not equal 
		
		boolean flag = Arrays.equals(a, b); //  by boolean data type , only two answers-true/false
         System.out.println(flag); // so the output is false
		
	}

}
