package Arraypractice;

import java.util.Arrays;

public class array_method_equals_exe4 {

	public static void main(String[] args) {
		int []a= {100,200,300,400,500,600,700,800,900,1000};
		int []b= {10,20,30,40,50,60,70,80,90,100};
		
		boolean flag=Arrays.equals(a, b);
		System.out.println(flag);
		
		if (flag =true)
		{
			for (int i=0; i<b.length; i++)
			{
				System.out.println(b[i]);
			}
		}
		else
		{
			for(int i=0; i<a.length; i++)
			{
				System.out.println(a[i]);
			}
		}
		
		
	}

}
