package Arraypractice;

public class array_exe_3 {

	public static void main(String[] args) {
		
		int []a= new int [10];
		
		a[0]=1;
		a[1]=12;
		a[2]=13;
		a[3]=14;
		a[4]=15;
		a[5]=16;
		a[6]=17;
		a[7]=18;
		a[8]=19;
		a[9]=100;
		
		for (int i= 0; i<a.length; i++)
		{
			System.out.println(a[i]);
		}
		
		

	}

}
