package Arraypractice;

import java.util.Arrays;

public class method_equals_exe3 {

	public static void main(String[] args) {
		
		int []a= {12,23,34,45,567,678};
		int[]b= {100,200,300,400,500,600,700,800,900,1000};
		
		boolean flag=Arrays.equals(a, b);     //equals method called 
	  System.out.println(flag);             
	  
	 
	  if(flag != false)                  //  if condition
	  {
		for(int i=0; i<b.length; i++)      // transverse using for loop 
		{
			System.out.println(b[i]);      
		}
	  }
	  else                                // else condition
	  {
		  for(int i=0; i<a.length; i++)         //transverse second condition using for loop
		  {
			  System.out.println(a[i]);
		  }
	  }
	}

}
