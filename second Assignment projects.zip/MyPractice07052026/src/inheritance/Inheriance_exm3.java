package inheritance;

class A
{
	int sum (int x, int y)
	{
		return x+y;
	}
	}
class B extends A
{
	int sub(int m, int n) {
		return m - n;
	}
}

class C extends B {
	int mul(int p, int q) {
		return p * q;
	}
}


public class Inheriance_exm3 {

	public static void main(String[] args) {
		C obj=new C();
		System.out.println(obj.mul(10, 10));
		System.out.println(obj.sum(10,10));
		System.out.println(obj.sub(100,10));
				

	}

}
