package inheritance;

class s1
{
	static void test()
	{
		System.out.println("Hello");
		
	}
}


public class Static_Method_exe_1 {

	public static void main(String[] args) {
		s1.test();
		
	}

}
