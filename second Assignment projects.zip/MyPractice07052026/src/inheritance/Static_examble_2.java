package inheritance;
class z1
{
	int id;
	String name;
	int age ;
	static String company="TCS";
	
	z1(int i, String n, int a)
	{
		id=i;
		name=n;
		age=a;
	}
	
	void display()
	{
		System.out.println(id+" "+name+" "+age+" "+company);
	}
	
}

public class Static_examble_2 {

	public static void main(String[] args) {
	  z1 obj= new z1(123, "Anand",29);
	  z1 obj1= new z1(345, "Swathy",28);
	  z1 obj2= new z1(678, "Aadhu",10);
	  z1 obj3= new z1(901, "Dhwani",11);
    obj.display();
    obj1.display();
    obj2.display();
    obj3.display();
    z1.company="Infosys";
    z1 obj4= new z1(234, "Bindhu",39);
    z1 obj5=new z1(567,"Sanal",40);
    obj4.display();
    obj5.display();
	}

}
