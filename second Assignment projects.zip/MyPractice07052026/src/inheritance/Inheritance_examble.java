package inheritance;

class a1
{
   void test()
   { 
 System.out.println("hello");
}
}

   class a2 extends a1
{
     void achu ()
       {
    	    System.out.println("hi");
     }   
}
   
   class  a3 extends a2
{
   void anand() 
    {
    	System.out.println("welcome");
    }
     
}
public class Inheritance_examble {

	public static void main(String[] args) {
		
		a3 obj =new a3();
		obj.test();
		obj.achu();
		obj.anand();
	}

}
