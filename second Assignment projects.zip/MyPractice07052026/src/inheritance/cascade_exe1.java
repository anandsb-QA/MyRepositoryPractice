package inheritance;

  class z
   {
	void run()
	{
		System.out.println("Running");
	}
  }  
  

 class x extends z
    {
	void walk()
	{
		System.out.println("Walking");
	}
}
 
 
 class y extends x
  {
	void jumb()
	{
		System.out.println("Jumbing");
	}
	
	void Activity()
	{
		run();
		walk();
		jumb();
	}
  }


public class cascade_exe1 {

	public static void main(String[] args) {
		y obj=new y();
		obj.Activity();
	}
}
