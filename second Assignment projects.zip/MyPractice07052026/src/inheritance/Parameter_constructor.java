package inheritance;

class Men
{
	Men(String i)
	{
		System.out.println("Anand");
	}
}

class Women extends Men
{
	Women(String j) 
	{
		super(j);
		System.out.println("Swathy");
	}
}

class child extends Women
{
	child(String k) 
	{
		super(k);
		System.out.println("Aadhu");
	}
}


public class Parameter_constructor {

	public static void main(String[] args) {
	child obj= new child("Aadhu");	

	}

}
