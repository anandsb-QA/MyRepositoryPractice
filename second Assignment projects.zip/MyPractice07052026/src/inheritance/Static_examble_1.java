package inheritance;
class b1
{
	int id;
	String ename;
	static String company="TCS";
	
	b1(int i ,String e)
	{
		id=i;
		ename=e;
	}
	void display()
	{
		System.out.println(id +" "+ename+" "+company);
	}
}

public class Static_examble_1 {

	public static void main(String[] args) {
	
		b1 obj =new b1(1234, "Anand");
		b1 obj1= new b1(1235, "Swathy");
		b1 obj2= new b1(1236, "Aadhu");
		obj.display();
		obj1.display();
		obj2.display();

	}

}
