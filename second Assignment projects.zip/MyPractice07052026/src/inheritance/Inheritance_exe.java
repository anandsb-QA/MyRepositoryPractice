package inheritance;

class a
{
   void test()
   { 
 System.out.println("hello");
}
}

   class b extends a
{
     void test1()
       {
    	    System.out.println("hi");
     }   
    
}   
   class  c extends a
{
   void anand() 
    {
    	System.out.println("welcome");
    }
     
}
public class Inheritance_exe {

	public static void main(String[] args) {
		
		c obj =new c();
		b obj1 =new b();
		obj.test();
		obj1.test1();
		obj.anand();
	}

}
