package inheritance;

class A2
{
	int sum(int x, int y)
	{
		return x+y;
	}
}

class B2 extends A2
   {
	int diff (int x, int y)
	{
		return x-y;
	}
}

class C2 extends B2
{
	int mul (int x, int y)
	{
		return(x*y);
	}
	void  math()
	{
		System.out.println(mul(10, 10));
		System.out.println(sum(10,10));
		System.out.println(diff(100,10));
	}
	
	}



public class Cascade_Para_exe2 {

	public static void main(String[] args) {
		
		C2 obj=new C2();
		obj.math();

	}

}
