package inheritance;

class animal
{
	animal()
	{
		System.out.println("i am a animal");
	
	}
}
 class dog extends animal
 {
	 dog()
	 {
		 super();
		 System.out.println("I am a dog");
		 
	 }
 }


public class Constructor {

	public static void main(String[] args) {
	dog obj =	new dog();
				
	}

}
