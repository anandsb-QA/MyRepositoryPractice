package Loopingstatement;

import java.util.Scanner;

public class Menudriven_pROGRAM {

	public static void main(String[] args) {
		
		int choice;
		
		Scanner sc =new Scanner(System.in);
		do {
			System.out.println("***CALCULATOR-MENU*****");
			System.out.println("1-Addition");
			System.out.println("2-substraction");
			System.out.println("3-Multplication");
			System.out.println("4-division");
			System.out.println("5-exit");
			System.out.println("Enter your Choice");
			choice= sc.nextInt();

		if (choice >0 && choice<=4)
		{
			System.out.println("Enter your first number");
			double a =sc.nextDouble();
			System.out.println("Enter your second number");
			double b =sc.nextDouble();
			
			switch(choice)
			{
			case 1:
				System.out.println("your answer is" +(a+b));
				break;
		    case 2:
		    	System.out.println("your answer is" +(a-b));
				break;
		    case 3:
				System.out.println("your answer is" +(a*b));
				break;
		    case 4:
		    	System.out.println("your answer is" +(a/b));
				break;
			default:
				System.out.println("exit");
				break;		
			}
			
		}

		}
		while(choice !=5);
		System.out.println("*****EXITING CALCULATOR*****Thank you for Using calculator service");
			
}
}
