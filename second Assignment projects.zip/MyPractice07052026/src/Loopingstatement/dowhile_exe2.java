package Loopingstatement;

public class dowhile_exe2 {

	public static void main(String[] args) {
      
		int x=10;
		int y=20;
		do
		{
			System.out.println(x+y);
			x++;
			y++;
		}
		while(x<50);
		
	}

}
