package Loopingstatement;

import java.util.Scanner;

public class Switch_choice {

	public static void main(String[] args) {
		
		int choice;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a option");
		
		choice = sc.nextInt();
		
		switch(choice)
		{
		case 1:
			System.out.println("First choice");
			break;
		case 2:
		    System.out.println("Second choice");
		    break;
		case 3:
			System.out.println("Third choice ");
			break;
		default:
			System.out.println("invalid");
		}
				

	}

}
