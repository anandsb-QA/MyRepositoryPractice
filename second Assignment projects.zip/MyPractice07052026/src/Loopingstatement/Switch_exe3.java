package Loopingstatement;

import java.util.Scanner;

public class Switch_exe3 {

	public static void main(String[] args) {
		int age;
		int companyid;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter your age");
		age= sc.nextInt();
		
		System.out.println("Enter your companyId");
		companyid =sc.nextInt();
		
		switch(age)
		{
		case 18:
			if (age==18 && companyid==0)
			{
				System.out.println("you are 18 years old and you are eligible");
			}
			else if (age < 18 && companyid==0)
			{
				System.out.println("You are less than 18 year old and you are not eligible");
			}
			else 
			{
				System.out.println("you are eligible");
			}
			break;
			
		default:
			System.out.println("you  are  25 and you are directly in");
			break;
		
		
	}

}
}