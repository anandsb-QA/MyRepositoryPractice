package Loopingstatement;

import java.util.Scanner;

public class Switch_exe2 {

	public static void main(String[] args) {
		String name;
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter your name");
		
		name= sc.nextLine();
		
		switch(name)
		{
		case "Anand":
			System.out.println("You are Anand SB");
			break;
		case "Arjun":
			System.out.println("You are not Anand ");
			break;
		default:
			System.out.println("you are  not");
			break;
		}
			
		
		}
		
	}

