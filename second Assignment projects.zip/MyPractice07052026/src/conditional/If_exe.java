package conditional;

public class If_exe {

	public static void main(String[] args) {
		
		int a=1;
		if (a>5)
		{
			System.out.println("My name is Anand");
			if (a>7)
			{
				System.out.println("I am from TVm");
				 if(a>100)
                {
	             System.out.println("I am 100 years old");
             }
			}
		}
		else 
		{
			System.out.println("sorry Incorrect Syntax");
		}
	}

}
