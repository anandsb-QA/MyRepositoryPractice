package conditional;

public class If_else_examble {

	public static void main(String[] args) {
		int a= 100;
		int b=20;
	    int c= 5;  
		if (a>b)
		{
			System.out.println(a+b);
		
			if(c<a)
				{
				System.out.println(b-a);
		}
		else 
		{
			System.out.println("not valid");
		}

	}

}}
