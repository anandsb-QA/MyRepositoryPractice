package conditional;

public class Finding_largest_three_number {

	public static void main(String[] args) {
	int a=10;
	int b=200;
	int c= 30;
	
	if (a>b && a>c)
			{
		 System.out.println("a is largest");
			}
	if (b>a && b>c)
	{
		System.out.println("B is the largest");
	
	}
	if (c>a && c>b)
	{
		System.out.println("C is the largest");
	}
	}

}
