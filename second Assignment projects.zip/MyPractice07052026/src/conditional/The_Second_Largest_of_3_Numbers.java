package conditional;

public class The_Second_Largest_of_3_Numbers {

	public static void main(String[] args) {
		int a= 20;
		int b= 10;
		int c= 15;
		
		if(a>b && a>c)
		{
			if (b>a)
			{
				System.out.println("B is the second largest ");
			}
			else 
			{
				System.out.println(" C is the second largest");
			}
		}
		if (b>a && b>c)
		{
		 if (a>c)
		 {
			 System.out.println("a is the  second largest");
		 }
		 else 
		 {
			 System.out.println("c is the  second largest");
		 }
		}
		if (c>a && c>b)
		{
			if(a>b)
			{
				System.out.println("a is the second largest ");
			}
			else 
			{
				System.out.println("b is the  second largest");
			}
		}
	}
	

}
