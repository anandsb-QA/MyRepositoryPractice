package Assignments_for_GSI;

import java.util.Scanner;

public class Number_is_odd_or_even {

	public static void main(String[] args) {
		int number;
		
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter a number");
		number= sc.nextInt();
		
		if(number % 2==0)
		{
			System.out.println("the number is even number");
		}
		 else
			System.out.println("the number is odd number");
		
		sc.close();
		}
	

	}


