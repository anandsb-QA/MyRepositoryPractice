package Assignments_for_GSI;

import java.util.Scanner;

public class Multiplication_table {

	public static void main(String[] args) {
	
		int num;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number");
		
		num= sc.nextInt();
		
		
		for (int i=1; i<=10; i++)
		{
			
			System.out.println(num+ "x" + i +"="+(num*i));
		}
sc.close();
	}

}
