package Assignments_for_GSI;

import java.util.Scanner;

public class Print_1to_n {

	public static void main(String[] args) {
		
		int n;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter the number ");
		n= sc.nextInt();
		
		for ( int i=1; i<=n; i++)
		{
			System.out.println(i);
		}
sc.close();
	}

}
