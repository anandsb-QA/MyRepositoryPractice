package Assignments_for_GSI;

import java.util.Scanner;

public class NumberISpositive_NEgativeORzero {

	public static void main(String[] args) {
	
		int numb;
		Scanner sc =new Scanner(System.in);
		
		System.out.println("Enter the number");
		
		numb=sc.nextInt();
		
		if (numb>0)
		{
			System.out.println(numb +" "+"is a positive number");
		}
		else if (numb==0)
		{
			System.out.println(numb +" "+"is a zero");
		}
		else 
		{
			System.out.println(numb +" "+"is a negative number");
		}
		sc.close();
	}

}
