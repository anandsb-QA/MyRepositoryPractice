package Assignments_for_GSI;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		int num;
		int x;
		int rev = 0;
		int rem;

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the number");
		num = sc.nextInt();

		x = num;

		while (num != 0)
		{
			rem = num % 10;
			rev = rev * 10 + rem;
			num = num / 10;
		}

		if (x == rev)
		{
			System.out.println(x + " is a palindrome number");
		}
		else
		{
			System.out.println(x + " is not a palindrome number");
		}

		sc.close();
		}
	}


