package Assignments_for_GSI;

import java.util.Scanner;

public class Find_the_largest_of_3_numbers {

	public static void main(String[] args) {
		
		int a;
		int b;
		int c;
		
	Scanner sc =new Scanner(System.in);
	
	System.out.println("Enter the number ");
	a= sc.nextInt();
	b= sc.nextInt();
	c= sc.nextInt();
			
	if(a>b)
	{
	   if (a>c)
	  {
		System.out.println(a+" " + "is the largest");  
	  }
	   else
	  {
		  System.out.println(c +" "+ "is the largest");
	  }
	}
	else
		if (b>c)
		{
			if(b>a)
				System.out.println(b +" "+ " is largest");	
		}
		else 
			System.out.println(c+" " +"is the largest");
	sc.close();	
		
	}

}
