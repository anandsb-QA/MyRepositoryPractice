package Assignments_for_GSI;

import java.util.Scanner;

public class Leapyear_program {

	public static void main(String[] args) {
		int year;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("enter the year");
		
		year = sc.nextInt();
		
		if (year % 4==0 && year !=100)
		{
			if(year %100 ==0)
			{
				System.out.println(year +" " +"-this is a Leap year");
			}
		else 
			{
				System.out.println(year +" " +"-this is not a Leap year");
			}	
		}
		sc.close();	
	}
	}
