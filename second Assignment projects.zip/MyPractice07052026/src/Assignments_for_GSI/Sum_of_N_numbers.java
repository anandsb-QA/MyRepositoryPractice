package Assignments_for_GSI;

import java.util.Scanner;

public class Sum_of_N_numbers {

	public static void main(String[] args) {
		
		int n;
		int sum=0;
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		
		n=sc.nextInt();
		
		for (int i=1; i<=n; i++)
		{
			sum=sum+i;
		}
			System.out.println("Total sum of N numbers is"+" "+ sum);
		
			sc.close();
		}
		
		
	}

