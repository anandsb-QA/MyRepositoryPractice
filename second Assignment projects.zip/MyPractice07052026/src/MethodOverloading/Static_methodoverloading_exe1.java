package MethodOverloading;
 
class a9
{
	static int add (int x, int y)
	{
		return x+y;
	}
	static int add (int x, int y ,int z)
	{
		return x+y+z;
	}
	
}

public class Static_methodoverloading_exe1 {

	public static void main(String[] args) {

	System.out.println(a9.add(10, 20));
	System.out.println(a9.add(11,12,13));
		
	}

}
